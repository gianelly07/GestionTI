using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class AsignarTecnicoTicket : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();
        private readonly TecnicoNegocio _tecnicoNegocio = new TecnicoNegocio();

        public AsignarTecnicoTicket()
        {
            InitializeComponent();
        }

        private void AsignarTecnicoTicket_Load(object sender, EventArgs e)
        {
            CargarTickets();

            cboxTecnico.Items.Clear();
            foreach (var t in _tecnicoNegocio.ObtenerDisponibles())
            {
                // t.TB_USUARIO es la navegacion generada por EF hacia TB_USUARIO (idTecnico -> idUsuario)
                cboxTecnico.Items.Add(t.idTecnico + " - " + t.TB_USUARIO.Nombre);
            }
        }

        private void CargarTickets()
        {
            dgvListaTicketsAsignar.DataSource = null;
            dgvListaTicketsAsignar.DataSource = _ticketNegocio.ObtenerSinAsignar();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cboxTecnico.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar un tecnico para asignarle a ese ticket");
                return;
            }
            if (dgvListaTicketsAsignar.SelectedRows.Count == 0)
            {
                MessageBox.Show("Debe seleccionar un ticket para asignarle un ticket");
                return;
            }

            int idTicket = (int)dgvListaTicketsAsignar.SelectedRows[0].Cells["idTicket"].Value;
            int idTecnico = int.Parse(cboxTecnico.Text.Split('-')[0].Trim());

            string error = _ticketNegocio.AsignarTecnico(idTicket, idTecnico, Sesion.UsuarioActivo.Nombre);
            if (error != null)
            {
                MessageBox.Show(error);
                cboxTecnico.SelectedIndex = -1;
                return;
            }

            CargarTickets();
        }
    }
}
