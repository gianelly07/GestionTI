using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class FrmAsignarRoles : Form
    {
        private readonly UsuarioNegocio _usuarioNegocio = new UsuarioNegocio();

        public FrmAsignarRoles()
        {
            InitializeComponent();
        }

        private void FrmAsignarRoles_Load(object sender, EventArgs e)
        {
            CargarUsuarios();
        }

        private void CargarUsuarios()
        {
            dgvListaUsuariosGeneral.DataSource = null;
            dgvListaUsuariosGeneral.DataSource = _usuarioNegocio.ObtenerTodos();
        }

        private void dgvListaUsuariosGeneral_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvListaUsuariosGeneral.SelectedRows.Count == 0)
            {
                MessageBox.Show("Debe selecionar un Usuario");
                return;
            }

            if (dgvListaUsuariosGeneral.SelectedRows.Count > 1)
            {
                MessageBox.Show("Debe selecionar solo un Usuario");
                return;
            }

            if (cboxRolesParaAsignar.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar un rol");
                return;
            }

            int idSeleccionado = (int)dgvListaUsuariosGeneral.SelectedRows[0].Cells["idUsuario"].Value;

            string error = _usuarioNegocio.AsignarRol(idSeleccionado, cboxRolesParaAsignar.Text);
            if (error != null)
            {
                MessageBox.Show(error);
                return;
            }

            CargarUsuarios();
        }
    }
}
