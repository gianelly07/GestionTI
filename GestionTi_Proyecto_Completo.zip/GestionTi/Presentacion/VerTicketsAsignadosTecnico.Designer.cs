﻿namespace Presentacion
{
    partial class VerTicketsAsignadosTecnico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvTicketsAsignados = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicketsAsignados)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTicketsAsignados
            // 
            this.dgvTicketsAsignados.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvTicketsAsignados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTicketsAsignados.Location = new System.Drawing.Point(12, 102);
            this.dgvTicketsAsignados.Name = "dgvTicketsAsignados";
            this.dgvTicketsAsignados.Size = new System.Drawing.Size(792, 334);
            this.dgvTicketsAsignados.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "GestiónTech";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(290, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Visualizacion de Tickets asignados";
            // 
            // VerTicketsAsignadosTecnico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(816, 472);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvTicketsAsignados);
            this.Name = "VerTicketsAsignadosTecnico";
            this.Text = "VerTicketsAsignadosTecnico";
            this.Load += new System.EventHandler(this.VerTicketsAsignadosTecnico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicketsAsignados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvTicketsAsignados;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}