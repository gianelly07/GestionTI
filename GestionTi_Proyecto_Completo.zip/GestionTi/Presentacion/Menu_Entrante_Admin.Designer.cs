﻿namespace Presentacion
{
    partial class Menu_Entrante_Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.filtrarTicketPorPrioridadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asignarRolesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ticketsPorTecnicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.distribuciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ticketsCategoriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filtrarTicketPorPrioridadToolStripMenuItem,
            this.asignarRolesToolStripMenuItem,
            this.ticketsPorTecnicoToolStripMenuItem,
            this.distribuciónToolStripMenuItem,
            this.ticketsCategoriaToolStripMenuItem,
            this.toolStripMenuItem1,
            this.tToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(907, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // filtrarTicketPorPrioridadToolStripMenuItem
            // 
            this.filtrarTicketPorPrioridadToolStripMenuItem.Name = "filtrarTicketPorPrioridadToolStripMenuItem";
            this.filtrarTicketPorPrioridadToolStripMenuItem.Size = new System.Drawing.Size(144, 20);
            this.filtrarTicketPorPrioridadToolStripMenuItem.Text = "AsignarTecnico a Ticket";
            this.filtrarTicketPorPrioridadToolStripMenuItem.Click += new System.EventHandler(this.filtrarTicketPorPrioridadToolStripMenuItem_Click);
            // 
            // asignarRolesToolStripMenuItem
            // 
            this.asignarRolesToolStripMenuItem.Name = "asignarRolesToolStripMenuItem";
            this.asignarRolesToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.asignarRolesToolStripMenuItem.Text = "AsignarRoles";
            this.asignarRolesToolStripMenuItem.Click += new System.EventHandler(this.asignarRolesToolStripMenuItem_Click);
            // 
            // ticketsPorTecnicoToolStripMenuItem
            // 
            this.ticketsPorTecnicoToolStripMenuItem.Name = "ticketsPorTecnicoToolStripMenuItem";
            this.ticketsPorTecnicoToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.ticketsPorTecnicoToolStripMenuItem.Text = "TicketsPorTecnico";
            this.ticketsPorTecnicoToolStripMenuItem.Click += new System.EventHandler(this.ticketsPorTecnicoToolStripMenuItem_Click);
            // 
            // distribuciónToolStripMenuItem
            // 
            this.distribuciónToolStripMenuItem.Name = "distribuciónToolStripMenuItem";
            this.distribuciónToolStripMenuItem.Size = new System.Drawing.Size(193, 20);
            this.distribuciónToolStripMenuItem.Text = "DistribuciónIncidenciasCategoria";
            // 
            // ticketsCategoriaToolStripMenuItem
            // 
            this.ticketsCategoriaToolStripMenuItem.Name = "ticketsCategoriaToolStripMenuItem";
            this.ticketsCategoriaToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.ticketsCategoriaToolStripMenuItem.Text = "TicketsPrioridad";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // tToolStripMenuItem
            // 
            this.tToolStripMenuItem.Name = "tToolStripMenuItem";
            this.tToolStripMenuItem.Size = new System.Drawing.Size(118, 20);
            this.tToolStripMenuItem.Text = "TiempoResolucion";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // Menu_Entrante_Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(907, 536);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu_Entrante_Admin";
            this.Text = "Menu_Entrante_Admin";
            this.Load += new System.EventHandler(this.Menu_Entrante_Admin_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem filtrarTicketPorPrioridadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ticketsPorTecnicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem distribuciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ticketsCategoriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asignarRolesToolStripMenuItem;
    }
}