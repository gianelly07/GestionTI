using System;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public partial class Menu_Registro : Form
    {
        private readonly UsuarioNegocio _usuarioNegocio = new UsuarioNegocio();

        public Menu_Registro()
        {
            InitializeComponent();
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            var usuario = new TB_USUARIO
            {
                Nombre = tbNombre.Text.Trim(),
                Apellido = tbApellido.Text.Trim(),
                email = tbEmail.Text.Trim(),
                password = tbContraseña.Text.Trim()
            };

            string error = _usuarioNegocio.Registrar(usuario);
            if (error != null)
            {
                MessageBox.Show(error);
                return;
            }

            MessageBox.Show("Registro exitoso");
            tbNombre.Clear();
            tbApellido.Clear();
            tbEmail.Clear();
            tbContraseña.Clear();
        }
    }
}
