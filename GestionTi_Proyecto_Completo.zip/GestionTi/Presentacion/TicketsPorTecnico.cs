using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class TicketsPorTecnico : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();
        private readonly TecnicoNegocio _tecnicoNegocio = new TecnicoNegocio();

        public TicketsPorTecnico()
        {
            InitializeComponent();
        }

        private void TicketsPorTecnico_Load(object sender, EventArgs e)
        {
            cboxTicketsTecnico.Items.Clear();
            foreach (var t in _tecnicoNegocio.ObtenerTodos())
            {
                cboxTicketsTecnico.Items.Add(t.idTecnico + " - " + t.TB_USUARIO.Nombre);
            }
            dgvTicketsPorTecnico.DataSource = null;
        }

        private void btnFiltrarTecnico_Click(object sender, EventArgs e)
        {
            if (cboxTicketsTecnico.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar un tecnico");
                return;
            }

            int idTecnico = int.Parse(cboxTicketsTecnico.Text.Split('-')[0].Trim());

            dgvTicketsPorTecnico.DataSource = null;
            dgvTicketsPorTecnico.DataSource = _ticketNegocio.ObtenerPorTecnico(idTecnico);
        }
    }
}
