﻿namespace Presentacion
{
    partial class Menu_Entrante_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.registrarNuevoTicketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizarEstadoTicketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verTodosMisTicketsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrarNuevoTicketToolStripMenuItem,
            this.visualizarEstadoTicketToolStripMenuItem,
            this.verTodosMisTicketsToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(644, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // registrarNuevoTicketToolStripMenuItem
            // 
            this.registrarNuevoTicketToolStripMenuItem.Name = "registrarNuevoTicketToolStripMenuItem";
            this.registrarNuevoTicketToolStripMenuItem.Size = new System.Drawing.Size(132, 20);
            this.registrarNuevoTicketToolStripMenuItem.Text = "RegistrarNuevoTicket";
            this.registrarNuevoTicketToolStripMenuItem.Click += new System.EventHandler(this.registrarNuevoTicketToolStripMenuItem_Click);
            // 
            // visualizarEstadoTicketToolStripMenuItem
            // 
            this.visualizarEstadoTicketToolStripMenuItem.Name = "visualizarEstadoTicketToolStripMenuItem";
            this.visualizarEstadoTicketToolStripMenuItem.Size = new System.Drawing.Size(135, 20);
            this.visualizarEstadoTicketToolStripMenuItem.Text = "VisualizarEstadoTicket";
            this.visualizarEstadoTicketToolStripMenuItem.Click += new System.EventHandler(this.visualizarEstadoTicketToolStripMenuItem_Click);
            // 
            // verTodosMisTicketsToolStripMenuItem
            // 
            this.verTodosMisTicketsToolStripMenuItem.Name = "verTodosMisTicketsToolStripMenuItem";
            this.verTodosMisTicketsToolStripMenuItem.Size = new System.Drawing.Size(123, 20);
            this.verTodosMisTicketsToolStripMenuItem.Text = "VerTodosMisTickets";
            this.verTodosMisTicketsToolStripMenuItem.Click += new System.EventHandler(this.verTodosMisTicketsToolStripMenuItem_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // Menu_Entrante_Usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(644, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu_Entrante_Usuario";
            this.Text = "Menu_Entrante_Usuario";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem registrarNuevoTicketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizarEstadoTicketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verTodosMisTicketsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
    }
}