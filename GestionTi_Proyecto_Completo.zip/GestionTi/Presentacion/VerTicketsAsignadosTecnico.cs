using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class VerTicketsAsignadosTecnico : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();

        public VerTicketsAsignadosTecnico()
        {
            InitializeComponent();
        }

        private void VerTicketsAsignadosTecnico_Load(object sender, EventArgs e)
        {
            dgvTicketsAsignados.DataSource = null;
            dgvTicketsAsignados.DataSource = _ticketNegocio.ObtenerPorTecnico(Sesion.UsuarioActivo.idUsuario);
        }
    }
}
