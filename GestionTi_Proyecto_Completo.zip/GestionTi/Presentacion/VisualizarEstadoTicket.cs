using System;
using System.Linq;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class VisualizarEstadoTicket : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();

        public VisualizarEstadoTicket()
        {
            InitializeComponent();
        }

        private void VisualizarEstadoTicket_Load(object sender, EventArgs e)
        {
            var idsTickets = _ticketNegocio.ObtenerTicketsDeUsuario(Sesion.UsuarioActivo.idUsuario)
                                            .Select(t => t.idTicket)
                                            .ToList();
            cboxTicketid.DataSource = null;
            cboxTicketid.DataSource = idsTickets;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int idTicket = int.Parse(cboxTicketid.Text);
            var ticket = _ticketNegocio.ObtenerPorId(idTicket);

            lstTicket.Items.Clear();
            if (ticket != null)
                lstTicket.Items.Add(ticket.Titulo + " ||Estado : " + ticket.Estado);
        }

        private void cboxTicketid_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
