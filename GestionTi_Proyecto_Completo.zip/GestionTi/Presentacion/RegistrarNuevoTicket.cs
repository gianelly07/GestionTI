using System;
using System.Windows.Forms;
using Entidades;
using Negocio;

namespace Presentacion
{
    public partial class RegistrarNuevoTicket : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();

        public RegistrarNuevoTicket()
        {
            InitializeComponent();
        }

        private void RegistrarNuevoTicket_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cboxPrioridad.SelectedIndex == -1)
            {
                MessageBox.Show("Debe elegir que prioridad tiene ese ticket (igual será evaluado por un admin)");
                return;
            }

            var ticket = new TB_TICKET
            {
                Titulo = tbTitulo.Text.Trim(),
                Descripcion = tbDescripcion.Text.Trim(),
                Prioridad = cboxPrioridad.Text,
                idSolicitante = Sesion.UsuarioActivo.idUsuario,
                idCategoria = 1, // TODO: reemplazar por un combo real de categorias (TB_CATEGORIA es NOT NULL)
                CreadoBy = Sesion.UsuarioActivo.Nombre,
                FechaCierre = DateTime.Now // TB_TICKET.FechaCierre es NOT NULL en la BD; se ajusta cuando el ticket se cierre de verdad
            };

            string error = _ticketNegocio.RegistrarTicket(ticket);
            if (error != null)
            {
                MessageBox.Show(error);
                return;
            }

            tbTitulo.Clear();
            tbDescripcion.Clear();
            cboxPrioridad.SelectedIndex = -1;
        }
    }
}
