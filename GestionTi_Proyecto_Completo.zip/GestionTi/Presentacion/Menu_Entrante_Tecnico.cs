using System;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class Menu_Entrante_Tecnico : Form
    {
        public Menu_Entrante_Tecnico()
        {
            InitializeComponent();
        }

        private void tickToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void filtrarTicketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FiltrarTicketPrioridadAsignado().ShowDialog();
        }

        private void salirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void verTicketsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new VerTicketsAsignadosTecnico().ShowDialog();
        }
    }
}
