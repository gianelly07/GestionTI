using Entidades;

namespace Presentacion
{
    // Guarda el usuario logueado para que cualquier formulario pueda consultarlo
    // sin depender directamente del formulario de login.
    public static class Sesion
    {
        public static TB_USUARIO UsuarioActivo { get; set; }
    }
}
