﻿namespace Presentacion
{
    partial class TicketsPorTecnico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvTicketsPorTecnico = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.cboxTicketsTecnico = new System.Windows.Forms.ComboBox();
            this.btnFiltrarTecnico = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicketsPorTecnico)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "GestiónTech";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tickets por tecnico :";
            // 
            // dgvTicketsPorTecnico
            // 
            this.dgvTicketsPorTecnico.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvTicketsPorTecnico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTicketsPorTecnico.Location = new System.Drawing.Point(17, 144);
            this.dgvTicketsPorTecnico.Name = "dgvTicketsPorTecnico";
            this.dgvTicketsPorTecnico.Size = new System.Drawing.Size(728, 274);
            this.dgvTicketsPorTecnico.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Tickets por tecnico :";
            // 
            // cboxTicketsTecnico
            // 
            this.cboxTicketsTecnico.FormattingEnabled = true;
            this.cboxTicketsTecnico.Location = new System.Drawing.Point(149, 89);
            this.cboxTicketsTecnico.Name = "cboxTicketsTecnico";
            this.cboxTicketsTecnico.Size = new System.Drawing.Size(126, 21);
            this.cboxTicketsTecnico.TabIndex = 5;
            // 
            // btnFiltrarTecnico
            // 
            this.btnFiltrarTecnico.BackColor = System.Drawing.Color.White;
            this.btnFiltrarTecnico.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFiltrarTecnico.Location = new System.Drawing.Point(582, 80);
            this.btnFiltrarTecnico.Name = "btnFiltrarTecnico";
            this.btnFiltrarTecnico.Size = new System.Drawing.Size(96, 30);
            this.btnFiltrarTecnico.TabIndex = 8;
            this.btnFiltrarTecnico.Text = "Filtrar";
            this.btnFiltrarTecnico.UseVisualStyleBackColor = false;
            this.btnFiltrarTecnico.Click += new System.EventHandler(this.btnFiltrarTecnico_Click);
            // 
            // TicketsPorTecnico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(819, 449);
            this.Controls.Add(this.btnFiltrarTecnico);
            this.Controls.Add(this.cboxTicketsTecnico);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvTicketsPorTecnico);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "TicketsPorTecnico";
            this.Text = "TicketsPorTecnico";
            this.Load += new System.EventHandler(this.TicketsPorTecnico_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicketsPorTecnico)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvTicketsPorTecnico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboxTicketsTecnico;
        private System.Windows.Forms.Button btnFiltrarTecnico;
    }
}