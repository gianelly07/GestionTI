using System;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class Menu_Entrante_Admin : Form
    {
        public Menu_Entrante_Admin()
        {
            InitializeComponent();
        }

        private void Menu_Entrante_Admin_Load(object sender, EventArgs e)
        {
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void asignarRolesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmAsignarRoles().ShowDialog();
        }

        private void filtrarTicketPorPrioridadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AsignarTecnicoTicket().ShowDialog();
        }

        private void ticketsPorTecnicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new TicketsPorTecnico().ShowDialog();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
