using System;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class Menu_Entrante_Usuario : Form
    {
        public Menu_Entrante_Usuario()
        {
            InitializeComponent();
        }

        private void registrarNuevoTicketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RegistrarNuevoTicket().ShowDialog();
        }

        private void verTodosMisTicketsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new VerTodosMisTickets().ShowDialog();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void visualizarEstadoTicketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new VisualizarEstadoTicket().ShowDialog();
        }
    }
}
