using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class FiltrarTicketPrioridadAsignado : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();

        public FiltrarTicketPrioridadAsignado()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void FiltrarTicketPrioridadAsignado_Load(object sender, EventArgs e)
        {
            dgvTicketsPorPrioridad.DataSource = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar una prioridad");
                return;
            }

            dgvTicketsPorPrioridad.DataSource = null;
            dgvTicketsPorPrioridad.DataSource =
                _ticketNegocio.ObtenerPorTecnicoYPrioridad(Sesion.UsuarioActivo.idUsuario, comboBox1.Text);
        }
    }
}
