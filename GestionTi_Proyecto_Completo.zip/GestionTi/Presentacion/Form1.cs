using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class Menu_InicioSesion : Form
    {
        private readonly UsuarioNegocio _usuarioNegocio = new UsuarioNegocio();

        public Menu_InicioSesion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbEmail.Text) || string.IsNullOrWhiteSpace(tbContraseña.Text))
            {
                MessageBox.Show("Por favor complete todos los campos");
                return;
            }

            string email = tbEmail.Text.Trim();
            string password = tbContraseña.Text.Trim();

            var usuario = _usuarioNegocio.Login(email, password);
            if (usuario == null)
            {
                MessageBox.Show("Contraseña o correo electronico incorrectos");
                return;
            }

            Sesion.UsuarioActivo = usuario;

            switch (usuario.rol)
            {
                case "Admin":
                    new Menu_Entrante_Admin().ShowDialog();
                    break;
                case "Usuario":
                    new Menu_Entrante_Usuario().ShowDialog();
                    break;
                case "Tecnico":
                    new Menu_Entrante_Tecnico().ShowDialog();
                    break;
            }

            tbContraseña.Clear();
            tbEmail.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Menu_Registro().ShowDialog();
        }
    }
}
