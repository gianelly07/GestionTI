using System;
using System.Windows.Forms;
using Negocio;

namespace Presentacion
{
    public partial class VerTodosMisTickets : Form
    {
        private readonly TicketNegocio _ticketNegocio = new TicketNegocio();

        public VerTodosMisTickets()
        {
            InitializeComponent();
        }

        private void VerTodosMisTickets_Load(object sender, EventArgs e)
        {
            dgvVisualizacionTickets.DataSource = null;
            dgvVisualizacionTickets.DataSource = _ticketNegocio.ObtenerTicketsDeUsuario(Sesion.UsuarioActivo.idUsuario);
        }
    }
}
