﻿namespace Presentacion
{
    partial class FrmAsignarRoles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvListaUsuariosGeneral = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboxRolesParaAsignar = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaUsuariosGeneral)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvListaUsuariosGeneral
            // 
            this.dgvListaUsuariosGeneral.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvListaUsuariosGeneral.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListaUsuariosGeneral.Location = new System.Drawing.Point(12, 36);
            this.dgvListaUsuariosGeneral.Name = "dgvListaUsuariosGeneral";
            this.dgvListaUsuariosGeneral.Size = new System.Drawing.Size(769, 204);
            this.dgvListaUsuariosGeneral.TabIndex = 0;
            this.dgvListaUsuariosGeneral.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListaUsuariosGeneral_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lista de Usuarios General";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Actualizacion de Rol :";
            // 
            // cboxRolesParaAsignar
            // 
            this.cboxRolesParaAsignar.FormattingEnabled = true;
            this.cboxRolesParaAsignar.Items.AddRange(new object[] {
            "Admin",
            "Usuario",
            "Tecnico"});
            this.cboxRolesParaAsignar.Location = new System.Drawing.Point(152, 254);
            this.cboxRolesParaAsignar.Name = "cboxRolesParaAsignar";
            this.cboxRolesParaAsignar.Size = new System.Drawing.Size(121, 21);
            this.cboxRolesParaAsignar.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(594, 298);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 30);
            this.button2.TabIndex = 8;
            this.button2.Text = "Actualizar Rol";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FrmAsignarRoles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(803, 356);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cboxRolesParaAsignar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvListaUsuariosGeneral);
            this.Name = "FrmAsignarRoles";
            this.Text = "FrmAsignarRoles";
            this.Load += new System.EventHandler(this.FrmAsignarRoles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListaUsuariosGeneral)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvListaUsuariosGeneral;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboxRolesParaAsignar;
        private System.Windows.Forms.Button button2;
    }
}