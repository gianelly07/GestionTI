﻿namespace Presentacion
{
    partial class VisualizarEstadoTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cboxTicketid = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lstTicket = new System.Windows.Forms.ListBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 42);
            this.label1.TabIndex = 3;
            this.label1.Text = "GestiónTech";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(278, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Visualización de estado de Ticket";
            // 
            // cboxTicketid
            // 
            this.cboxTicketid.FormattingEnabled = true;
            this.cboxTicketid.Location = new System.Drawing.Point(88, 90);
            this.cboxTicketid.Name = "cboxTicketid";
            this.cboxTicketid.Size = new System.Drawing.Size(140, 21);
            this.cboxTicketid.TabIndex = 5;
            this.cboxTicketid.SelectedIndexChanged += new System.EventHandler(this.cboxTicketid_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 23);
            this.label3.TabIndex = 6;
            this.label3.Text = "Ticket id :";
            // 
            // lstTicket
            // 
            this.lstTicket.FormattingEnabled = true;
            this.lstTicket.Location = new System.Drawing.Point(7, 134);
            this.lstTicket.Name = "lstTicket";
            this.lstTicket.Size = new System.Drawing.Size(395, 82);
            this.lstTicket.TabIndex = 7;
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.White;
            this.btnBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.Location = new System.Drawing.Point(248, 90);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(109, 24);
            this.btnBuscar.TabIndex = 10;
            this.btnBuscar.Text = "BuscarIdTicket";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // VisualizarEstadoTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(452, 254);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.lstTicket);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboxTicketid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "VisualizarEstadoTicket";
            this.Text = "VisualizarEstadoTicket";
            this.Load += new System.EventHandler(this.VisualizarEstadoTicket_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboxTicketid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstTicket;
        private System.Windows.Forms.Button btnBuscar;
    }
}