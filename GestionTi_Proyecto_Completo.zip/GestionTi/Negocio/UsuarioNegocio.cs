using System.Collections.Generic;
using Datos;
using Entidades;

namespace Negocio
{
    public class UsuarioNegocio
    {
        private readonly UsuarioDatos _usuarioDatos = new UsuarioDatos();
        private readonly TecnicoDatos _tecnicoDatos = new TecnicoDatos();
        private readonly AdminDatos _adminDatos = new AdminDatos();

        public List<TB_USUARIO> ObtenerTodos()
        {
            return _usuarioDatos.ObtenerTodos();
        }

        // Devuelve el usuario si el login es correcto, o null si no lo es.
        public TB_USUARIO Login(string email, string password)
        {
            var usuario = _usuarioDatos.ObtenerPorEmail(email);

            if (usuario == null || usuario.password != password)
                return null;

            return usuario;
        }

        // Devuelve null si el registro fue exitoso, o un mensaje de error si no.
        public string Registrar(TB_USUARIO usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.Nombre) ||
                string.IsNullOrWhiteSpace(usuario.Apellido) ||
                string.IsNullOrWhiteSpace(usuario.email) ||
                string.IsNullOrWhiteSpace(usuario.password))
            {
                return "Debe rellenar todos los campos para poder registrarse";
            }

            if (_usuarioDatos.ExisteEmail(usuario.email))
            {
                return "Ese email ya está registrado";
            }

            _usuarioDatos.Registrar(usuario);
            return null;
        }

        // Devuelve null si la asignacion fue exitosa, o un mensaje de error si no.
        public string AsignarRol(int idUsuario, string nuevoRol)
        {
            var usuario = _usuarioDatos.ObtenerPorId(idUsuario);
            if (usuario == null)
                return "Usuario no encontrado";

            if (nuevoRol == "Tecnico")
            {
                _tecnicoDatos.Crear(new TB_TECNICO
                {
                    idTecnico = idUsuario,
                    especialidad = "General",
                    estado = "Disponible"
                });
            }
            else if (nuevoRol == "Admin")
            {
                _adminDatos.Crear(new TB_ADMIN { idAdmin = idUsuario });
            }

            _usuarioDatos.ActualizarRol(idUsuario, nuevoRol);
            return null;
        }
    }
}
