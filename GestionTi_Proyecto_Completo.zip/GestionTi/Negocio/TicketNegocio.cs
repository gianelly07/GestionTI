using System;
using System.Collections.Generic;
using Datos;
using Entidades;

namespace Negocio
{
    public class TicketNegocio
    {
        private const int MAX_TICKETS_POR_TECNICO = 5;

        private readonly TicketDatos _ticketDatos = new TicketDatos();
        private readonly TecnicoDatos _tecnicoDatos = new TecnicoDatos();

        // Devuelve null si el registro fue exitoso, o un mensaje de error si no.
        public string RegistrarTicket(TB_TICKET ticket)
        {
            if (string.IsNullOrWhiteSpace(ticket.Titulo) || string.IsNullOrWhiteSpace(ticket.Descripcion))
                return "Debe rellenar todos los campos para poder registrar el ticket de la atencion";

            if (string.IsNullOrWhiteSpace(ticket.Prioridad))
                return "Debe elegir que prioridad tiene ese ticket (igual será evaluado por un admin)";

            ticket.Estado = "Abierto";
            ticket.FechaApertura = DateTime.Now;
            ticket.CreadoAt = DateTime.Now;

            _ticketDatos.Registrar(ticket);
            return null;
        }

        public List<TB_TICKET> ObtenerTicketsDeUsuario(int idSolicitante)
        {
            return _ticketDatos.ObtenerPorSolicitante(idSolicitante);
        }

        public List<TB_TICKET> ObtenerSinAsignar()
        {
            return _ticketDatos.ObtenerSinAsignar();
        }

        public List<TB_TICKET> ObtenerPorTecnico(int idTecnico)
        {
            return _ticketDatos.ObtenerPorTecnico(idTecnico);
        }

        public List<TB_TICKET> ObtenerPorTecnicoYPrioridad(int idTecnico, string prioridad)
        {
            return _ticketDatos.ObtenerPorTecnicoYPrioridad(idTecnico, prioridad);
        }

        public TB_TICKET ObtenerPorId(int idTicket)
        {
            return _ticketDatos.ObtenerPorId(idTicket);
        }

        // Devuelve null si la asignacion fue exitosa, o un mensaje de error si no.
        public string AsignarTecnico(int idTicket, int idTecnico, string usuarioQueAsigna)
        {
            var tecnico = _tecnicoDatos.ObtenerPorId(idTecnico);
            if (tecnico == null)
                return "Técnico no encontrado";

            if (tecnico.estado != "Disponible")
                return "El tecnico no está disponible";

            int ticketsAsignados = _tecnicoDatos.ContarTicketsAsignados(idTecnico);
            if (ticketsAsignados >= MAX_TICKETS_POR_TECNICO)
                return "El tecnico no está disponible";

            _ticketDatos.AsignarTecnico(idTicket, idTecnico, usuarioQueAsigna);
            return null;
        }
    }
}
