using System.Collections.Generic;
using Datos;
using Entidades;

namespace Negocio
{
    public class CategoriaNegocio
    {
        private readonly CategoriaDatos _categoriaDatos = new CategoriaDatos();

        public List<TB_CATEGORIA> ObtenerTodas()
        {
            return _categoriaDatos.ObtenerTodas();
        }
    }
}
