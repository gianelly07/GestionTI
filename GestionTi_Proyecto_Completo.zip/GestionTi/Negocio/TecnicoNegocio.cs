using System.Collections.Generic;
using Datos;
using Entidades;

namespace Negocio
{
    public class TecnicoNegocio
    {
        private readonly TecnicoDatos _tecnicoDatos = new TecnicoDatos();

        public List<TB_TECNICO> ObtenerTodos()
        {
            return _tecnicoDatos.ObtenerTodos();
        }

        public List<TB_TECNICO> ObtenerDisponibles()
        {
            return _tecnicoDatos.ObtenerDisponibles();
        }
    }
}
