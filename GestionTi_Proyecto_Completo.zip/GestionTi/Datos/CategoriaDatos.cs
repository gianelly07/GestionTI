using System.Collections.Generic;
using System.Linq;
using Entidades;

namespace Datos
{
    public class CategoriaDatos
    {
        public List<TB_CATEGORIA> ObtenerTodas()
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_CATEGORIA.ToList();
            }
        }
    }
}
