using System;
using System.Collections.Generic;
using System.Linq;
using Entidades;

namespace Datos
{
    public class UsuarioDatos
    {
        public List<TB_USUARIO> ObtenerTodos()
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_USUARIO.ToList();
            }
        }

        public TB_USUARIO ObtenerPorId(int idUsuario)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_USUARIO.FirstOrDefault(u => u.idUsuario == idUsuario);
            }
        }

        public TB_USUARIO ObtenerPorEmail(string email)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_USUARIO.FirstOrDefault(u => u.email == email);
            }
        }

        public bool ExisteEmail(string email)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_USUARIO.Any(u => u.email == email);
            }
        }

        public void Registrar(TB_USUARIO usuario)
        {
            using (var contexto = new GestionTIEntities())
            {
                usuario.rol = "Usuario";
                usuario.CreatedAt = DateTime.Now;
                contexto.TB_USUARIO.Add(usuario);
                contexto.SaveChanges();
            }
        }

        public void ActualizarRol(int idUsuario, string nuevoRol)
        {
            using (var contexto = new GestionTIEntities())
            {
                var usuario = contexto.TB_USUARIO.FirstOrDefault(u => u.idUsuario == idUsuario);
                if (usuario == null) return;

                usuario.rol = nuevoRol;
                usuario.ModifiedAt = DateTime.Now;
                contexto.SaveChanges();
            }
        }
    }
}
