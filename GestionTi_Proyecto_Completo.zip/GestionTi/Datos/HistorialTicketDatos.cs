using System.Collections.Generic;
using System.Linq;
using Entidades;

namespace Datos
{
    public class HistorialTicketDatos
    {
        public List<TB_HISTORIAL_TICKET> ObtenerPorTicket(int idTicket)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_HISTORIAL_TICKET.Where(h => h.idTicket == idTicket).ToList();
            }
        }
    }
}
