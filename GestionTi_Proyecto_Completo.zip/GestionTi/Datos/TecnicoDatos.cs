using System.Collections.Generic;
using System.Linq;
using Entidades;

namespace Datos
{
    public class TecnicoDatos
    {
        public List<TB_TECNICO> ObtenerTodos()
        {
            using (var contexto = new GestionTIEntities())
            {
                // Include para traer el Usuario relacionado (nombre, apellido, etc.)
                return contexto.TB_TECNICO.Include("TB_USUARIO").ToList();
            }
        }

        public List<TB_TECNICO> ObtenerDisponibles()
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TECNICO.Include("TB_USUARIO")
                                         .Where(t => t.estado == "Disponible")
                                         .ToList();
            }
        }

        public TB_TECNICO ObtenerPorId(int idTecnico)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TECNICO.Include("TB_USUARIO")
                                         .FirstOrDefault(t => t.idTecnico == idTecnico);
            }
        }

        public void Crear(TB_TECNICO tecnico)
        {
            using (var contexto = new GestionTIEntities())
            {
                contexto.TB_TECNICO.Add(tecnico);
                contexto.SaveChanges();
            }
        }

        public int ContarTicketsAsignados(int idTecnico)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TICKET.Count(t => t.idTecnico == idTecnico && t.Estado != "Cerrado");
            }
        }
    }
}
