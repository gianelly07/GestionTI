using Entidades;

namespace Datos
{
    public class AdminDatos
    {
        public void Crear(TB_ADMIN admin)
        {
            using (var contexto = new GestionTIEntities())
            {
                contexto.TB_ADMIN.Add(admin);
                contexto.SaveChanges();
            }
        }
    }
}
