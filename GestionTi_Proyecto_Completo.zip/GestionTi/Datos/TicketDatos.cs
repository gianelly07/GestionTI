using System;
using System.Collections.Generic;
using System.Linq;
using Entidades;

namespace Datos
{
    public class TicketDatos
    {
        public void Registrar(TB_TICKET ticket)
        {
            using (var contexto = new GestionTIEntities())
            {
                contexto.TB_TICKET.Add(ticket);
                contexto.SaveChanges();
            }
        }

        public List<TB_TICKET> ObtenerPorSolicitante(int idSolicitante)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TICKET.Where(t => t.idSolicitante == idSolicitante).ToList();
            }
        }

        public List<TB_TICKET> ObtenerSinAsignar()
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TICKET.Where(t => t.idTecnico == null).ToList();
            }
        }

        public List<TB_TICKET> ObtenerPorTecnico(int idTecnico)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TICKET.Where(t => t.idTecnico == idTecnico).ToList();
            }
        }

        public List<TB_TICKET> ObtenerPorTecnicoYPrioridad(int idTecnico, string prioridad)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TICKET
                    .Where(t => t.idTecnico == idTecnico && t.Prioridad == prioridad)
                    .ToList();
            }
        }

        public TB_TICKET ObtenerPorId(int idTicket)
        {
            using (var contexto = new GestionTIEntities())
            {
                return contexto.TB_TICKET.FirstOrDefault(t => t.idTicket == idTicket);
            }
        }

        public void AsignarTecnico(int idTicket, int idTecnico, string usuarioQueAsigna)
        {
            using (var contexto = new GestionTIEntities())
            {
                var ticket = contexto.TB_TICKET.FirstOrDefault(t => t.idTicket == idTicket);
                if (ticket == null) return;

                string estadoAnterior = ticket.Estado;

                ticket.idTecnico = idTecnico;
                ticket.Estado = "En Proceso";
                ticket.ModificadoBy = usuarioQueAsigna;
                ticket.ModificadoAt = DateTime.Now;

                contexto.TB_HISTORIAL_TICKET.Add(new TB_HISTORIAL_TICKET
                {
                    idTicket = idTicket,
                    estadoAnterior = estadoAnterior,
                    estadoNuevo = "En Proceso",
                    comentario = "Tecnico asignado.",
                    idUsuario = idTecnico,
                    fechaCambio = DateTime.Now
                });

                contexto.SaveChanges();
            }
        }
    }
}
